/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PracticaJPA.Model;

import PracticaJPA.Persist.CompaniesDAO;
import PracticaJPA.Persist.EmployeesDAO;
import java.util.List;

/**
 *
 * @author Ricard Hernández
 */
public class Model {

    CompaniesDAO companiesDao;
    EmployeesDAO employeesDao;

    public Model() {
        companiesDao = new CompaniesDAO();
        employeesDao = new EmployeesDAO();
    }

    public List<Company> listAllCompanies() {
        List<Company> companies;
        companies = companiesDao.listAllCompanies();
        return companies;
    }

    public List<Employee> listCompanyEmployees(int id) {
        List<Employee> employees;
        Company company = companiesDao.findCompanyById(id);
        if (company != null) {
            employees = company.getEmployeeList();

        } else {
            
           employees = null;
                   
        }
        return employees;
    }

    public Company findCompanyById(int id) {
        Company company = companiesDao.findCompanyById(id);
        return company;
    }

    public int removeCompany(Company company) {
        int result = companiesDao.removeCompany(company);
        return result;
    }

    public int modifyCompany(Company company, Company oldCompany) {
        int result = companiesDao.modifyCompany(company, oldCompany);
        return result;
    }

    public int insertCompany(Company company) {
        Company r;
        int result;
        r = companiesDao.findCompanyByCif(company.getCif());
        if (r != null) {
            result = -1;
        } else {
            result = companiesDao.addNewCompany(company);
        }
        return result;
    }

    public List<Employee> listAllEmployes() {
        List<Employee> employees;
        employees = employeesDao.listAllEmployees();
        return employees;
    }

    public int modifyEmployee(Employee employee, Employee oldEmployee) {
        int result = employeesDao.modifyEmployee(employee, oldEmployee);
        return result;
    }
    public int removeEmployee(Employee employee) {
        int result = employeesDao.removeEmployee(employee);
        return result;
    }
    public List<Employee> listEmployeesLikeFirstName(String firstName){
        List<Employee> employees = employeesDao.listEmployeesLikeFirstName(firstName);
        
        return employees;
    }
    public Employee findEmployeeyById(int id){
        Employee employee = employeesDao.findEmployeeById(id);
        return employee;
    }
}
