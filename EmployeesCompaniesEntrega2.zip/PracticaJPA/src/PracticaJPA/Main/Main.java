package PracticaJPA.Main;

import PracticaJPA.Controllers.Controler;
import PracticaJPA.Model.Company;
import PracticaJPA.Model.Employee;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author ProvenSoft
 */
public class Main {

    private String[] mainMenu = {
        "Exit", "List all companies", "List company employees (given the company id)",
        "Add new company", "Modify company (given the id)",
        "Remove company (given the id)",
        "List all Employees (for all companies)", "List persons like firstname",
        "Company hires an employee (given a company id)",
        "Modify employee (given the id)",
        "Remove employee (given the id) "
    };
    Controler controler;

    public static void main(String[] args) {

        Main myApp = new Main();
        myApp.run();

    }

    private void run() {
        controler = new Controler();
        boolean exit = false;

        do {
            int selectedOption = showMenu();

            switch (selectedOption) {
                case 0:
                    exit = true;
                    break;
                case 1:
                    listAllCompanies();
                    break;
                case 2:
                    listCompanyEmployees();
                    break;
                case 3:
                    addNewCompany();
                    break;
                case 4:
                    modifyCompany();
                    break;
                case 5:
                    removeCompany();
                    break;
                case 6:
                    listAllEmployees();
                    break;
                case 7:
                    listPersonsLikeFirstname();
                    break;
                case 8:
                    companyHiresAnEmployee();
                    break;
                case 9:
                    modifyEmployee();
                    break;
                case 10:
                    removeEmployee();
                    break;
                default:
                    System.out.println("Invalid option!");
                    break;
            }

        } while (!exit);

        System.out.println("Goodbye!");

    }

    private int showMenu() {
        System.out.println("=====Store main menu=======");
        for (int i = 0; i < mainMenu.length; i++) {
            System.out.format("[%d]. %s\n", i, mainMenu[i]);
        }
        System.out.print("Select an option: ");
        Scanner sc = new Scanner(System.in);
        int selectedOption;
        try {
            selectedOption = sc.nextInt();

            if ((selectedOption < 0)
                    || (selectedOption >= mainMenu.length)) {
                selectedOption = -1;
            }
        } catch (InputMismatchException e) {

            selectedOption = -1;
        }

        return selectedOption;
    }

    private void listAllCompanies() {
        List<Company> companies = controler.listAllCompanies();
        if (companies != null) {
            companies.forEach((company) -> {
                System.out.println("La compañía " + company.getNameCompany() + " con CIF " + company.getCif() + " tiene el id asignado " + company.getId() + " y fué fundada en el año " + company.getFoundationYear());
            });
        } else {
            System.out.println("La compañia es nula");
        }

    }

    private void listCompanyEmployees() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Dime el id: ");
        int id = sc.nextInt();

        List<Employee> employees = controler.listCompanyEmployees(id);
        if (employees != null) {
            System.out.println("Se van a imprimir los empleados de la compañía ");
            for (Employee employee : employees) {
                System.out.println(employee.getFirstName());
            }
        } else {
            System.out.println("La lista fué nula");
        }

    }

    private void addNewCompany() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Dime el cif");
        String cif = sc.nextLine();

        System.out.println("Dime el año");
        int year = sc.nextInt();

        System.out.println("Dime el nombre ");
        String name = sc.nextLine();

        Company company = new Company(cif, year, name);
        int result = controler.addNewCompany(company);
        switch (result) {
            case -1:
                System.out.println("Ya existe una empresa con el mismo CIF");
                break;
            case 0:
                System.out.println("No se ha podido añadir esta empresa");
                break;
            default:
                System.out.println("Se ha añadido la empresa");
                break;
        }

    }

    private void modifyCompany() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Dime del id ");
        int id = sc.nextInt();
        Company oldCompany = controler.findCompanyById(id);
        if (oldCompany != null) {
            System.out.println("Se va a modificar la compañia " + oldCompany.getNameCompany());
            System.out.println("Dime el CIF :");
            String cif = sc.next();
            System.out.println("Dime al año de fundacion: ");
            int year = sc.nextInt();
            System.out.println("Dime el nombre: ");
            String name = sc.nextLine();
            Company newCompany = new Company(cif, year, name);
            String respuesta = "";
            do {
                System.out.println("Seguro que quieres modificarla?");
                respuesta = sc.next().toUpperCase();
                switch (respuesta) {
                    case "S":
                        int result = controler.modifyCompany(newCompany, oldCompany);
                        if (result != 0) {
                            System.out.println("Se ha modificado la compañía");
                        } else {
                            System.out.println("No se ha podido modificar la compañía");
                        }
                        break;
                    case "N":
                        System.out.println("Has respondido que no quieres modificarla");
                        break;
                    default:
                        System.out.println("Respuesta incorrecta");
                        break;
                }
            } while (!respuesta.equals("S") && !respuesta.equals("N"));

        } else {
            System.out.println("La compañía no se encuentra en la base de datos");

        }
    }

    private void removeCompany() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Dime el id: ");
        int id = sc.nextInt();
        Company company = new Company(id);
        int result;
        result = controler.removeCompany(company);
        if (result == -1) {
            System.out.println("No se ha podido eliminar la compañia porque tiene empleados a su cargo");
        } else {
            if (result == 0) {
                System.out.println("No se ha podido eliminar la compañia.");
            } else {
                System.out.println("Se han eliminado " + result + " compañia/s.");
            }

        }

    }

    private void listAllEmployees() {
        List<Employee> employees = controler.listAllEmployes();
        if (employees != null) {
            employees.forEach((Employee employee) -> {
                System.out.println("El empleado " + employee.getFirstName() + " " + employee.getLastName() + " tiene el id asignado " + employee.getId() + " trabaja en la empresa con el id " + employee.getIdEmpresa() + "con teletrabajo: " + employee.getHomeWorking());
            });
        } else {
            System.out.println("La compañia es nula");
        }
    }

    private void listPersonsLikeFirstname() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Dime el nombre: ");
        String firstName = sc.nextLine();
        List<Employee> employees = controler.listEmployeesLikeFirstName(firstName);
        if (employees != null) {
            for (Employee employee : employees) {
                System.out.println(employee.toString());
            }
        } else {
            System.out.println("No hay trabajadores con este nombre");
        }
    }

    private void companyHiresAnEmployee() {
        //TODO
    }

    private void modifyEmployee() {
      Scanner sc = new Scanner(System.in);
        System.out.println("Dime del id ");
        int id = sc.nextInt();
        Employee oldEmployee = controler.findEmployeeById(id);
        if (oldEmployee != null) {
            System.out.println("Se va a modificar la compañia " + oldEmployee.getFirstName());
            System.out.println("Dime el nombre:");
            String name = sc.nextLine();
            System.out.println("Dime el apellido: ");
            String apelido = sc.nextLine();
            System.out.println("Dime el salario");
            double salary = sc.nextDouble();
            Employee newEmployee = new Employee(name, apelido, salary);
            String respuesta = "";
            do {
                System.out.println("Seguro que quieres modificarlo?");
                respuesta = sc.nextLine().toUpperCase();
                switch (respuesta) {
                    case "S":
                        int result = controler.modifyEmployee(newEmployee,oldEmployee );
                        if (result != 0) {
                            System.out.println("Se ha modificado el empleado");
                        } else {
                            System.out.println("No se ha podido modificar el empleado");
                        }
                        break;
                    case "N":
                        System.out.println("Has respondido que no quieres modificarlo");
                        break;
                    default:
                        System.out.println("Respuesta incorrecta");
                        break;
                }
            } while (!respuesta.equals("S") && !respuesta.equals("N"));

        } else {
            System.out.println("El empleado no se encuentra en la base de datos");

        }
        
    }

    private void removeEmployee() {

        Scanner sc = new Scanner(System.in);
        System.out.println("Dime el id: ");
        int id = sc.nextInt();
        Employee employee = new Employee(id);
        int result;
        result = controler.removeEmployee(employee);
        if (result == -1) {
            System.out.println("No se ha podido eliminar el empleado porque ha ocurrido un problema");
        } else {
            if (result == 0) {
                System.out.println("No se ha eliminado ningun empleado.");
            } else {
                System.out.println("Se han eliminado " + result + " empleado/s.");
            }

        }
    }

}
