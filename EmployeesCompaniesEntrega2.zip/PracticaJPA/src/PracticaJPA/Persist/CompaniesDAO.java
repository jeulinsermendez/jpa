/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PracticaJPA.Persist;

import PracticaJPA.Model.Company;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 *
 * @author Ricard Hernández
 */
public class CompaniesDAO {

    public CompaniesDAO() {
    }

    public List<Company> listAllCompanies() {
        List<Company> companies;
        try {
            EntityManagerFactory factory = Persistence.createEntityManagerFactory("PracticaJPAPU");
            EntityManager manager = factory.createEntityManager();
            TypedQuery<Company> allCompanies = manager.createNamedQuery("Company.findAll", Company.class);
            companies = allCompanies.getResultList();
            manager.close();
            factory.close();
        } catch (Exception e) {
            companies = null;
        }

        return companies;
    }

    public Company findCompanyById(int id) {
        Company company;
        try {
            EntityManagerFactory factory = Persistence.createEntityManagerFactory("PracticaJPAPU");
            EntityManager manager = factory.createEntityManager();
            TypedQuery<Company> companyById = manager.createNamedQuery("Company.findById", Company.class);
            companyById.setParameter("id", id);
            company = companyById.getSingleResult();
            manager.close();
            factory.close();
        } catch (Exception e) {
            company = null;
        }
        return company;
    }
    
    public Company findCompanyByCif(String cif) {
        Company company;
        try {
            EntityManagerFactory factory = Persistence.createEntityManagerFactory("PracticaJPAPU");
            EntityManager manager = factory.createEntityManager();
            TypedQuery<Company> companyById = manager.createNamedQuery("Company.findByCif", Company.class);
            companyById.setParameter("cif", cif);
            company = companyById.getSingleResult();
            manager.close();
            factory.close();
        } catch (Exception e) {
            company = null;
        }
        return company;
    }

    public int addNewCompany(Company company) {
        int result;
        try {
            EntityManagerFactory factory = Persistence.createEntityManagerFactory("PracticaJPAPU");
            EntityManager manager = factory.createEntityManager();
            String query = "INSERT INTO company (cif,foundationYear,name_company) VALUES(?,?,?)";
            Query tq = manager.createNativeQuery(query);
            tq.setParameter(1, company.getCif());
            tq.setParameter(2, company.getFoundationYear());
            tq.setParameter(3, company.getNameCompany());
            manager.getTransaction().begin();
            result = tq.executeUpdate();
            manager.getTransaction().commit();
            manager.close();
            factory.close();

        } catch (Exception e) {
            result = 0;
        }
        return result;

    }

    public int modifyCompany(Company company, Company oldCompany) {
        int result;
        try {
            EntityManagerFactory factory = Persistence.createEntityManagerFactory("PracticaJPAPU");
            EntityManager manager = factory.createEntityManager();
            String query = "UPDATE company set cif = ? , foundationYear = ? , name_company = ?  WHERE id = ?";
            Query tq = manager.createNativeQuery(query);
            tq.setParameter(1, company.getCif());
            tq.setParameter(2, company.getFoundationYear());
            tq.setParameter(3, company.getNameCompany());
            tq.setParameter(4, oldCompany.getId());
            manager.getTransaction().begin();
            result = tq.executeUpdate();
            manager.getTransaction().commit();
            manager.close();
            factory.close();

        } catch (Exception e) {
            result = 0;
        }
        return result;
    }

    public int removeCompany(Company company) {
        int result;
        try {
            EntityManagerFactory factory = Persistence.createEntityManagerFactory("PracticaJPAPU");
            EntityManager manager = factory.createEntityManager();
            String query = "DELETE from Company c WHERE c.id = :id";
            Query tq = manager.createQuery(query);
            tq.setParameter("id", company.getId());
            manager.getTransaction().begin();
            result = tq.executeUpdate();
            manager.getTransaction().commit();
            manager.close();
            factory.close();
        } catch (Exception e) {
            result = 0;
        }
        return result;
    }
}
