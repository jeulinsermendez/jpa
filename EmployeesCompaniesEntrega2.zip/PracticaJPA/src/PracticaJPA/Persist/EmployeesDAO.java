/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PracticaJPA.Persist;

import PracticaJPA.Model.Company;
import PracticaJPA.Model.Employee;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 *
 * @author Ricard Hernández
 */
public class EmployeesDAO {

    public EmployeesDAO() {
    }

    public List<Employee> listAllEmployees() {
        List<Employee> employees;
        try {
            EntityManagerFactory factory = Persistence.createEntityManagerFactory("PracticaJPAPU");
            EntityManager manager = factory.createEntityManager();
            TypedQuery<Employee> allEmployees = manager.createNamedQuery("Employee.findAll", Employee.class);
            employees = allEmployees.getResultList();
            manager.close();
            factory.close();
        } catch (Exception e) {
            employees = null;
        }

        return employees;
    }

    public int modifyEmployee(Employee employee, Employee oldEmployee) {
        int result;
        try {
            EntityManagerFactory factory = Persistence.createEntityManagerFactory("PracticaJPAPU");
            EntityManager manager = factory.createEntityManager();
            String query = "UPDATE employee set firstName = ? , lastName = ? , salary = ?, homeWorking = ?, id_empresa = ?  WHERE id = ?";
            Query tq = manager.createNativeQuery(query);
            tq.setParameter(1, employee.getFirstName());
            tq.setParameter(2, employee.getLastName());
            tq.setParameter(3, employee.getSalary());
            tq.setParameter(4, employee.getHomeWorking());
            tq.setParameter(5, employee.getIdEmpresa());
            tq.setParameter(6, oldEmployee.getId());
            manager.getTransaction().begin();
            result = tq.executeUpdate();
            manager.getTransaction().commit();
            manager.close();
            factory.close();

        } catch (Exception e) {
            result = 0;
        }
        return result;
    }

    public int removeEmployee(Employee employee) {
        int result;
        try {
            EntityManagerFactory factory = Persistence.createEntityManagerFactory("PracticaJPAPU");
            EntityManager manager = factory.createEntityManager();
            String query = "DELETE from Employee e WHERE e.id = :id";
            Query tq = manager.createQuery(query);
            tq.setParameter("id", employee.getId());
            manager.getTransaction().begin();
            result = tq.executeUpdate();
            manager.getTransaction().commit();
            manager.close();
            factory.close();
        } catch (Exception e) {
            result = -1;
        }
        return result;
    }
    
    public List<Employee> listEmployeesLikeFirstName(String firstName) {
        List<Employee> employees;
        try {
            EntityManagerFactory factory = Persistence.createEntityManagerFactory("PracticaJPAPU");
            EntityManager manager = factory.createEntityManager();
            TypedQuery<Employee> allEmployees = manager.createNamedQuery("Employee.findByFirstName", Employee.class);
            allEmployees.setParameter("firstName", firstName);
            employees = allEmployees.getResultList();
            manager.close();
            factory.close();
        } catch (Exception e) {
            employees = null;
        }

        return employees;
    }
    public Employee findEmployeeById(int id) {
        Employee employee;
        try {
            EntityManagerFactory factory = Persistence.createEntityManagerFactory("PracticaJPAPU");
            EntityManager manager = factory.createEntityManager();
            TypedQuery<Employee> employeeById = manager.createNamedQuery("Employee.findById", Employee.class);
            employeeById.setParameter("id", id);
            employee = employeeById.getSingleResult();
            manager.close();
            factory.close();
        } catch (Exception e) {
            employee = null;
        }
        return employee;
    }

}
