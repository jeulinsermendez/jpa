/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PracticaJPA.Controllers;

import PracticaJPA.Model.Company;
import PracticaJPA.Model.Employee;
import PracticaJPA.Model.Model;
import java.util.List;

/**
 *
 * @author Ricard Hernández
 */
public class Controler {
    
    Model model;
    
    public Controler(){
        model = new Model();
    }
    
    public List<Company> listAllCompanies() {
        List<Company> companies = model.listAllCompanies();
        return companies;
    }

    public List<Employee> listCompanyEmployees(int id){
        List<Employee> employees = model.listCompanyEmployees(id);
        return employees;
    }
    public Company findCompanyById(int id){
        Company company = model.findCompanyById(id);
        return company;
    }

    public int addNewCompany(Company company) {
        int result = model.insertCompany(company);
        return result;
    }

    public int modifyCompany(Company company,Company oldCompany) {
        int result = model.modifyCompany(company,oldCompany);
        return result;
    }

    public int removeCompany(Company company) {
      int result = model.removeCompany(company);
      return result;
    }

   public List<Employee> listAllEmployes(){
        List<Employee> employees;
        employees = model.listAllEmployes();
        return employees; 
    }

    public List<Employee> listEmployeesLikeFirstName(String firstName){
        List<Employee> employees = model.listEmployeesLikeFirstName(firstName);
        return employees;
    }

    public void companyHiresAnEmployee() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int modifyEmployee(Employee employee, Employee oldEmployee) {
        int result = model.modifyEmployee(employee, oldEmployee);
        return result;    }

    public int removeEmployee(Employee employee) {
      int result = model.removeEmployee(employee);
      return result;
    }
    public Employee findEmployeeById(int id){
        Employee employee = model.findEmployeeyById(id);
        return employee;
    }
    
}
